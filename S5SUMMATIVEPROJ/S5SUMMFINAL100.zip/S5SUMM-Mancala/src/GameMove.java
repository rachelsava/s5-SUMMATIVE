/**
 * The possible cases for a moves outcome. 
 * Tells the game what to do from Pits class. 
 */
public enum GameMove {
	EXTRA_TURN,STEAL_STONES, GO_TO_NEXT,
}